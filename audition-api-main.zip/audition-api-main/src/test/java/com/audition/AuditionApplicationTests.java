package com.audition;

import com.audition.model.AuditionPost;
import com.audition.model.PostComment;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.List;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.test.web.server.LocalServerPort;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ProblemDetail;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit.jupiter.SpringExtension;


@ExtendWith(SpringExtension.class)
@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT)
class AuditionApplicationTests {

    static final String LOCALHOST = "http://localhost:";

    @LocalServerPort
    private transient int port;

    @Autowired
    private transient TestRestTemplate testRestTemplate;

    @Autowired
    private transient ObjectMapper objectMapper;

    @Test
    void testGetPostsByUserId() {
        final ResponseEntity<List<AuditionPost>> responseEntity = testRestTemplate.exchange(
            LOCALHOST + port + "/audition-api/posts?userId=1",
            HttpMethod.GET,
            null,
            new ParameterizedTypeReference<>() {
            });
        Assertions.assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
        final List<AuditionPost> posts = responseEntity.getBody();
        Assertions.assertNotNull(posts);
        Assertions.assertFalse(posts.isEmpty());
        Assertions.assertEquals(1, posts.get(0).getUserId());
    }

    @Test
    void testGetPostsByUserIdProblemDetails() throws Exception {
        final String response = testRestTemplate.getForObject(
            LOCALHOST + port + "/audition-api/posts?userId=-1", String.class);
        Assertions.assertNotNull(response);
        final ProblemDetail problemDetail = objectMapper.readValue(response, ProblemDetail.class);
        Assertions.assertNotNull(problemDetail);
        Assertions.assertEquals(404, problemDetail.getStatus());
        Assertions.assertEquals("Resource Not Found", problemDetail.getTitle());
        Assertions.assertEquals("Cannot find a Post having userId : -1", problemDetail.getDetail());
    }

    @Test
    void testGetPostById() {
        final ResponseEntity<AuditionPost> responseEntity = testRestTemplate.getForEntity(
            LOCALHOST + port + "/audition-api/posts/2", AuditionPost.class);
        Assertions.assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
        final AuditionPost auditionPost = responseEntity.getBody();
        Assertions.assertNotNull(auditionPost);
        Assertions.assertEquals(2, auditionPost.getId());
    }

    @Test
    void testGetPostByIdProblemDetails() throws Exception {
        final String response = testRestTemplate.getForObject(
            LOCALHOST + port + "/audition-api/posts/-1", String.class);
        Assertions.assertNotNull(response);
        final ProblemDetail problemDetail = objectMapper.readValue(response, ProblemDetail.class);
        Assertions.assertNotNull(problemDetail);
        Assertions.assertEquals(404, problemDetail.getStatus());
        Assertions.assertEquals("Resource Not Found", problemDetail.getTitle());
        Assertions.assertEquals("Cannot find a Post with id -1", problemDetail.getDetail());
    }

    @Test
    void testGetPostByIdProblemDetails2() throws Exception {
        final String response = testRestTemplate.getForObject(
            LOCALHOST + port + "/audition-api/posts/gfg", String.class);
        Assertions.assertNotNull(response);
        final ProblemDetail problemDetail = objectMapper.readValue(response, ProblemDetail.class);
        Assertions.assertNotNull(problemDetail);
        Assertions.assertEquals(400, problemDetail.getStatus());
        Assertions.assertEquals("Post Id path param must be numeric Only", problemDetail.getTitle());
        Assertions.assertEquals("Invalid Post Id : gfg", problemDetail.getDetail());
    }

    @Test
    void testGetPostCommentsByPostId() {
        final ResponseEntity<AuditionPost> responseEntity = testRestTemplate.getForEntity(
            LOCALHOST + port + "/audition-api/posts/3/comments", AuditionPost.class);
        Assertions.assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
        final AuditionPost auditionPost = responseEntity.getBody();
        Assertions.assertNotNull(auditionPost);
        Assertions.assertEquals(3, auditionPost.getId());
        Assertions.assertNotNull(auditionPost.getPostComments());
        Assertions.assertFalse(auditionPost.getPostComments().isEmpty());
    }

    @Test
    void testGetCommentsByPostId() {
        final ResponseEntity<List<PostComment>> responseEntity = testRestTemplate.exchange(
            LOCALHOST + port + "/audition-api/comments?postId=4",
            HttpMethod.GET,
            null,
            new ParameterizedTypeReference<>() {
            });
        final List<PostComment> comment = responseEntity.getBody();
        Assertions.assertNotNull(comment);
        Assertions.assertFalse(comment.isEmpty());
        Assertions.assertEquals(4, comment.get(0).getPostId());
        Assertions.assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
    }


    @Test
    void testGetCommentsByPostIdProblemDetails() throws Exception {
        final String response = testRestTemplate.getForObject(
            LOCALHOST + port + "/audition-api/comments?postId=-1", String.class);
        Assertions.assertNotNull(response);
        final ProblemDetail problemDetail = objectMapper.readValue(response, ProblemDetail.class);
        Assertions.assertNotNull(problemDetail);
        Assertions.assertEquals(404, problemDetail.getStatus());
        Assertions.assertEquals("Resource Not Found", problemDetail.getTitle());
        Assertions.assertEquals("Cannot find a comment for postId : -1", problemDetail.getDetail());
    }

}
