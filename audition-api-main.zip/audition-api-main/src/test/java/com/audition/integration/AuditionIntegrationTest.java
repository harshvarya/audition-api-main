package com.audition.integration;

import com.audition.model.AuditionPost;
import com.audition.model.PostComment;
import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

@ExtendWith(MockitoExtension.class)
class AuditionIntegrationTest {

    @Mock
    private static RestTemplate template;

    @InjectMocks
    private static AuditionIntegrationClient client;

    private static AuditionPost post;
    private static List<PostComment> comments;

    @BeforeAll
    static void init() {
        post = new AuditionPost();
        comments = new ArrayList<>();
        post.setId(123);
        final PostComment comment = new PostComment();
        comment.setId(456);
        comments.add(comment);
        post.setPostComments(comments);
    }

    @Test
    void testGetPostById() {
        Mockito.when(template.getForEntity(Mockito.anyString(), Mockito.any()))
            .thenReturn(new ResponseEntity<>(post, HttpStatus.OK));
        final AuditionPost post = client.getPostById("123");
        Assertions.assertEquals(123, post.getId());
    }


}
