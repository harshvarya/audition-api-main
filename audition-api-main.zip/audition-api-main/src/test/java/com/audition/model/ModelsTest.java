package com.audition.model;

import java.util.ArrayList;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class ModelsTest {

    public static final String TEST_BODY = "test_body";
    public static final String TEST_NAME = "test_name";

    @Test
    void testAuditionPost() {
        final AuditionPost post = new AuditionPost();
        post.setBody(TEST_BODY);
        post.setId(123);
        post.setTitle("test_title");
        post.setUserId(123);
        post.setPostComments(new ArrayList<>());

        Assertions.assertEquals(123, post.getId());
        Assertions.assertEquals(123, post.getUserId());
        Assertions.assertEquals("test_title", post.getTitle());
        Assertions.assertEquals(TEST_BODY, post.getBody());
        Assertions.assertEquals(0, post.getPostComments().size());

    }

    @Test
    void testPostComment() {
        final PostComment postComment = new PostComment();
        postComment.setPostId(123);
        postComment.setEmail("abc@gmail.com");
        postComment.setName(TEST_NAME);
        postComment.setBody(TEST_BODY);
        postComment.setId(123);
        Assertions.assertEquals(123, postComment.getPostId());
        Assertions.assertEquals(123, postComment.getId());
        Assertions.assertEquals(TEST_BODY, postComment.getBody());
        Assertions.assertEquals(TEST_NAME, postComment.getName());
        Assertions.assertEquals("abc@gmail.com", postComment.getEmail());
    }
}
