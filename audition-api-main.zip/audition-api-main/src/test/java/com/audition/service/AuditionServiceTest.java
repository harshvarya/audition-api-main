package com.audition.service;

import com.audition.integration.AuditionIntegrationClient;
import com.audition.model.AuditionPost;
import com.audition.model.PostComment;
import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class AuditionServiceTest {

    static final String POST_ID_123 = "123";
    @Mock
    private transient AuditionIntegrationClient client;

    @InjectMocks
    private transient AuditionService service;

    private static AuditionPost post;
    private static List<PostComment> comments;

    @BeforeAll
    static void init() {
        comments = new ArrayList<>();
        post = new AuditionPost();
        post.setId(123);
        final PostComment comment = new PostComment();
        comment.setId(456);
        comments.add(comment);
        post.setPostComments(comments);
    }

    @Test
    void testGetPosts() {
        Mockito.when(client.getPosts()).thenReturn(List.of(post));
        final List<AuditionPost> list = service.getPosts();
        Assertions.assertEquals(1, list.size());
    }

    @Test
    void testGetPostById() {
        Mockito.when(client.getPostById(POST_ID_123)).thenReturn(post);
        final AuditionPost post2 = service.getPostById(POST_ID_123);
        Assertions.assertEquals(123, post2.getId());
    }

    @Test
    void testGetPostWithComments() {
        Mockito.when(client.getPostWithComments(POST_ID_123)).thenReturn(post);
        final AuditionPost post2 = service.getPostWithComments(POST_ID_123);
        Assertions.assertEquals(123, post2.getId());
        Assertions.assertEquals(1, post2.getPostComments().size());
    }

    @Test
    void testGetComments() {
        Mockito.when(client.getCommentsByPostIdQueryParam(POST_ID_123)).thenReturn(comments);
        final List<PostComment> commentList = service.getComments(POST_ID_123);
        Assertions.assertEquals(1, commentList.size());
        Assertions.assertEquals(456, commentList.get(0).getId());
    }
}
