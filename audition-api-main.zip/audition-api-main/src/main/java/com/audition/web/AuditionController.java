package com.audition.web;

import com.audition.common.exception.SystemException;
import com.audition.model.AuditionPost;
import com.audition.model.PostComment;
import com.audition.service.AuditionService;
import jakarta.validation.constraints.NotBlank;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/audition-api")
public class AuditionController {

    @Autowired
    private transient AuditionService auditionService;

    private static final Logger LOGGER = LoggerFactory.getLogger(AuditionController.class);

    @RequestMapping(value = "/posts", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public @ResponseBody List<AuditionPost> getPosts(@RequestParam("userId") final String userId) {
        LOGGER.info("getPosts:: request param usedId : {}", userId);
        List<AuditionPost> posts = auditionService.getPosts();
        if (!posts.isEmpty()) {
            posts = posts.stream()
                .filter(auditionPost -> String.valueOf(auditionPost.getUserId()).equals(userId))
                .toList();
        }
        if (posts.isEmpty()) {
            throw new SystemException(String.format("Cannot find a Post having userId : %s", userId),
                "Resource Not Found",
                404);
        }
        return posts;
    }

    @RequestMapping(value = "/posts/{id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public @ResponseBody AuditionPost getPost(@PathVariable("id") @NotBlank final String postId) {
        LOGGER.info("getPost:: request path param postId : {}", postId);
        try {
            Integer.parseInt(postId);
        } catch (NumberFormatException ex) {
            throw new SystemException(String.format("Invalid Post Id : %s", postId),
                "Post Id path param must be numeric Only",
                400, ex);
        }
        final AuditionPost auditionPost = auditionService.getPostById(postId);
        LOGGER.info("getPost:: responding post for postId : {}", postId);
        return auditionPost;
    }


    @RequestMapping(value = "/posts/{postId}/comments", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public @ResponseBody AuditionPost getPostWithComments(@PathVariable("postId") @NotBlank final String postId) {
        LOGGER.info("getPostWithComments:: request path param postId : {}", postId);
        final AuditionPost auditionPost = auditionService.getPostWithComments(postId);
        LOGGER.info("getPostWithComments:: responding post for postId : {}", postId);
        return auditionPost;
    }

    @RequestMapping(value = "/comments", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public @ResponseBody List<PostComment> getComments(@RequestParam("postId") @NotBlank final String postId) {
        LOGGER.info("getComments:: request path param postId : {}", postId);
        final List<PostComment> postComments = auditionService.getComments(postId);
        if (postComments.isEmpty()) {
            throw new SystemException(String.format("Cannot find a comment for postId : %s", postId),
                "Resource Not Found",
                404);
        }
        LOGGER.info("getComments:: responding comments for postId : {}", postId);
        return postComments;
    }
}
