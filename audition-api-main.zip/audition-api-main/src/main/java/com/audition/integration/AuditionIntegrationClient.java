package com.audition.integration;

import com.audition.common.exception.SystemException;
import com.audition.model.AuditionPost;
import com.audition.model.PostComment;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

@Component
public class AuditionIntegrationClient {

    public final static String BASE_URL = "https://jsonplaceholder.typicode.com";
    public final static String POSTS = "posts";
    public final static String COMMENTS = "comments";
    public final static String POST_ID = "postId";

    @Autowired
    private transient RestTemplate restTemplate;

    public List<AuditionPost> getPosts() {
        final String url = String.format("%s/%s", BASE_URL, POSTS);
        final ResponseEntity<List<AuditionPost>> responseEntity =
            restTemplate.exchange(
                url,
                HttpMethod.GET,
                null,
                new ParameterizedTypeReference<>() {
                }
            );
        return responseEntity.getBody();
    }

    public AuditionPost getPostById(final String postId) {
        try {
            final String url = String.format("%s/%s/%s", BASE_URL, POSTS, postId);
            final ResponseEntity<AuditionPost> responseEntity =
                restTemplate.getForEntity(
                    url,
                    AuditionPost.class
                );
            return responseEntity.getBody();

        } catch (final HttpClientErrorException e) {
            if (e.getStatusCode() == HttpStatus.NOT_FOUND) {
                throw new SystemException(String.format("Cannot find a Post with id %s", postId),
                    "Resource Not Found",
                    404, e);
            } else {
                throw new SystemException(e.getMessage(), e);
            }
        }
    }

    public AuditionPost getPostWithComments(final String postId) {

        final AuditionPost auditionPostOptional = getPostById(postId);
        final String url = String.format("%s/%s/%s/%s", BASE_URL, POSTS, postId, COMMENTS);
        final ResponseEntity<List<PostComment>> responseEntity =
            restTemplate.exchange(
                url,
                HttpMethod.GET,
                null,
                new ParameterizedTypeReference<>() {
                }
            );
        final List<PostComment> postComments = responseEntity.getBody();
        auditionPostOptional.setPostComments(postComments);

        return auditionPostOptional;
    }

    public List<PostComment> getCommentsByPostIdQueryParam(final String postId) {

        final String url = String.format("%s/%s?%s=%s", BASE_URL, COMMENTS, POST_ID, postId);
        final ResponseEntity<List<PostComment>> responseEntity =
            restTemplate.exchange(
                url,
                HttpMethod.GET,
                null,
                new ParameterizedTypeReference<>() {
                }
            );
        return responseEntity.getBody();
    }
}
