# audition-api rest end points

- GET:  /audition-api/posts?userId=12

<pre>
This endpoint is used to get the posts for a specified usedId
</pre>

- GET: /audition-api/posts/12

<pre>
This endpoint is to get a post for the specified post id
</pre>

- GET: /audition-api/posts/12/comments

<pre>
This endpoint is to get a post along with comments for the specified post id
</pre>

- GET: /audition-api/comments?postId=2

<pre>
This endpoint is to get the comments for a specified post id
</pre>

- GET : /actuator/health

<pre>
This is the non-secured actuator endpoint is to see the health of the running app
</pre>

- GET : /actuator/info

<pre>
This is the non-secured actuator endpoint is to see the information of the running app
</pre>

